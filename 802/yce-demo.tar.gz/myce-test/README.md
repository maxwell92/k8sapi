refer to goweb-basic-sheet.go

lack of upload.html and upload-client.go

need /statics/js css ...
